step 1: Compile Main.java file

step 2: run that Main file

step 3: connect to the server using port 2000

step 4: follow instractions that show in the terminal
	Enter name:(user name)
	Enter symbol:(symbol that exist in .csv file)
	Enter bid:(enter bid more than current bid)

step 5: you can see update in the GUI after above data entered!	

Thank you!